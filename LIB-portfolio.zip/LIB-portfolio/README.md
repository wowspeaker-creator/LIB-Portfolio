
# LIB-portfolio — Toll Demand & Revenue Modeling + Accessibility Metrics

This repository contains a small, reproducible portfolio that mirrors your LIB report workflow: data prep, discrete-choice model estimation, validation & policy scenarios, and accessibility metrics. It is set up so you can run notebooks end-to-end and reproduce key tables/plots with explicit constants (e.g., **annualization = 317.5**, **toll price elasticity = −0.5**).

> **Note:** The notebooks are included here as _placeholders_ with parameters, TODO markers, and import scaffolding. Replace them with your finalized notebooks if you already have them, or build on the stubs directly.

---

## Repository structure
```
LIB-portfolio/
├── 01_data_prep.ipynb
├── 02_model_estimation.ipynb
├── 03_validation_and_scenarios.ipynb
├── accessibility_metrics.ipynb
├── data/
│   ├── mcc_counts.csv                # Manual Classified Counts
│   ├── atc_24h.csv                   # Automatic Traffic Count (24h profile)
│   ├── od_wtp.csv                    # OD and willingness-to-pay fields
│   ├── journey_time.csv              # Observed journey times
│   ├── zones.csv                     # Zonal definitions/centroids
│   └── skim_distance.csv             # Distance (and/or time) skim
├── outputs/                          # models, tables, plots (auto-created)
├── README.md
└── requirements.txt
```

---

## Quick start
1. **Create & activate environment**
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   pip install -U pip
   pip install -r requirements.txt
   ```
2. **Add data**: place the required CSVs in `data/` with the filenames shown above.
3. **Run notebooks in order**:
   1) `01_data_prep.ipynb` → validation, cleaning, `*_clean.csv` outputs.  
   2) `02_model_estimation.ipynb` → MNL with robust SEs; saves `outputs/mnl_model_results.pickle`.  
   3) `03_validation_and_scenarios.ipynb` → fit stats, elasticities, Scenario 2 (+10%/5yrs), macro growth.  
   4) `accessibility_metrics.ipynb` → count- vs utility-based accessibility (logsum).

---

## Project constants (default values)
- **Annualization factor**: `317.5` (daily → annual)
- **Toll price elasticity**: `-0.5`
- **Macro growth (illustrative)**: GDP per capita ≈ `0.67%/yr`, population ≈ `2.5%/yr`
- **Scenario 2**: `+10%` toll increase every 5 years over 2025–2050

> These are declared in the first code cell of each notebook under a **Parameters** section so you can keep a single source of truth across the workflow.

---

## Data dictionary (expected fields)
- `mcc_counts.csv`: date/time, location/plaza, class, count.
- `atc_24h.csv`: location/plaza, class, hour, count (0–23), 24‑hour totals.
- `od_wtp.csv`: origin, destination, `tt_min`, `toll_cost`, `toll_wtp`, and any segmentation fields.
- `journey_time.csv`: origin, destination, observed `tt_min` (or link-level times to be skimmed).
- `zones.csv`: zone id, name, centroid coordinates, and any demographics.
- `skim_distance.csv`: OD matrix of distances (and/or baseline times); can be turned into time skim.

> Replace plaza/class shares with your **MCC/ATC** proportions to compute revenue by class and plaza accurately.

---

## Notebooks — what they do
1. **01_data_prep.ipynb**
   - Validates required CSVs and schema basics.
   - Standardizes labels, parses datetimes, builds OD keys, and writes `*_clean.csv` to `data/`.
2. **02_model_estimation.ipynb**
   - Baseline Multinomial Logit (statsmodels MNLogit) with **HC1 robust SEs**.
   - Encodes destination choice using OD/WTP fields.
   - Saves a pickled results object for downstream use and attempts optional Biogeme import.
3. **03_validation_and_scenarios.ipynb**
   - Loads the saved MNL model; reports LL, pseudo‑R², AIC, BIC.
   - Computes elasticities; implements **Scenario 2** over 2025–2050 with macro growth.
4. **accessibility_metrics.ipynb**
   - Compares **count‑based** vs **utility‑based (logsum)** accessibility, swapping in estimated `B_TIME`/`B_COST` from 02-model when ready.

---

## Optional: Biogeme / Mixed or Nested Logit
- The stubs gracefully skip Biogeme if not installed.
- If you want NL/MXL, install later and extend the modeling cell blocks.

---

## Outputs
- All generated artifacts (cleaned CSVs, model pickles, plots) are written to `outputs/`.

---

## Notes
- If you already have your own notebooks, simply **overwrite** the placeholders in the repo root.
- Add plaza‑level revenue tables by merging MCC/ATC class shares with plaza assignment (TP1/TP2/TP3) from your report tables.

---

**Maintainer**: Ayobami Oyegbemile  
**Created**: 2026-01-22

